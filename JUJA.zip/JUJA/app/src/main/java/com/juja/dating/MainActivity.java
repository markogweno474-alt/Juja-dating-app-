package com.juja.dating;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout screen = new LinearLayout(this);
        screen.setOrientation(LinearLayout.VERTICAL);
        screen.setGravity(Gravity.CENTER);
        screen.setPadding(30, 30, 30, 30);
        screen.setBackgroundColor(Color.rgb(255, 241, 247));

        TextView logo = new TextView(this);
        logo.setText("JUJA");
        logo.setTextSize(48);
        logo.setTypeface(null, Typeface.BOLD);
        logo.setTextColor(Color.rgb(225, 45, 115));
        logo.setGravity(Gravity.CENTER);

        TextView tagline = new TextView(this);
        tagline.setText("Make meaningful connections.");
        tagline.setTextSize(17);
        tagline.setTextColor(Color.rgb(100, 65, 80));
        tagline.setGravity(Gravity.CENTER);

        TextView description = new TextView(this);
        description.setText(
            "Discover people, share interests\nand build genuine connections."
        );
        description.setTextSize(15);
        description.setGravity(Gravity.CENTER);
        description.setTextColor(Color.DKGRAY);
        description.setPadding(10, 30, 10, 35);

        Button createAccount = new Button(this);
        createAccount.setText("CREATE ACCOUNT");

        createAccount.setOnClickListener(v ->
            Toast.makeText(this,
                "Registration is coming next!",
                Toast.LENGTH_SHORT).show()
        );

        Button login = new Button(this);
        login.setText("LOG IN");

        login.setOnClickListener(v ->
            Toast.makeText(this,
                "Login is coming next!",
                Toast.LENGTH_SHORT).show()
        );

        screen.addView(logo);
        screen.addView(tagline);
        screen.addView(description);
        screen.addView(createAccount);
        screen.addView(login);

        setContentView(screen);
    }
}